import { create } from 'axios';

export const apiReceitas = create({
    baseURL: 'http://10.10.85.43:3000',
})

apiReceitas.interceptors.request.use((request) => {
    console.log('INTERCEPTANDO REQUISIÇÃO')
    console.log('URL:', request.url);
    console.log('CORPO:', request.data);
    console.log('--------');   

    return request;
});