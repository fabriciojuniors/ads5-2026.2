import { useReceitasFetch } from "@/hook/useReceitasFetch";
import { Receita } from "@/types/receita";
import { useEffect, useState } from "react";
import { Alert, Button, FlatList, StyleSheet, Text, TextInput, View } from "react-native";

export default function Index() {
  const { listar, criar } = useReceitasFetch();
  const [receitas, setReceitas] = useState<Receita[]>([]);
  const [novaReceita, setNovaReceita] = useState('');

  const cadastrarReceita = async () => {
    try {
      await criar({
        nome: novaReceita,
        ingredientes: '-',
        tempoPreparo: 10
      });
      setNovaReceita('');
      carregarReceitas()
    } catch (e) {
      Alert.alert("Erro ao cadastrar receita!");
    }
  }

  const carregarReceitas = async () => {
    const resposta = await listar()
    setReceitas(resposta);
  }

  useEffect(() => {
    carregarReceitas()
  }, [])


  return (
    <View style={styles.container}>
      <TextInput 
        placeholder="Informe o nome da receita" 
        value={novaReceita}
        onChangeText={setNovaReceita}
      />
      <Button title="Cadastrar" onPress={cadastrarReceita} />
      <FlatList
        data={receitas}
        renderItem={({ item }) => (
          <View>
            <Text>{item.id} - {item.nome}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 15
  },
});
