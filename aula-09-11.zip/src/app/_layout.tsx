import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Tabs } from "expo-router";
import { CakeSlice } from 'lucide-react-native';

const queryClient = new QueryClient()

export default function RootLayout() {
  return (
    <QueryClientProvider client={queryClient}>
      <Tabs>
        <Tabs.Screen
          name="index"
          options={{
            title: 'Receitas (fetch)',
            tabBarLabel: 'Fetch',
            tabBarIcon: ({ color, size }) => (
              <CakeSlice size={size} color={color} />
            )
          }}
        />
        <Tabs.Screen
          name="axios"
          options={{
            title: 'Receitas (axios)',
            tabBarLabel: 'Axios',
            tabBarIcon: ({ color, size }) => (
              <CakeSlice size={size} color={color} />
            )
          }}
        />
      </Tabs>
    </QueryClientProvider>
  );
}
