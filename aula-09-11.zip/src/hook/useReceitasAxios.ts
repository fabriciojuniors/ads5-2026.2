import { Receita } from "@/types/receita";
import { apiReceitas } from "@/utils/api";

export function useReceitasAxios() {

    const listar = async () => {
        const { data } = await apiReceitas.get<Receita[]>('/receitas')
        return data;
    }

    const obterPorId = async (id: string) => {
        const { data } = await apiReceitas.get<Receita>(`/receitas/${id}`);
        return data;
    }

    const criar = async(receita: Omit<Receita, 'id'>) => {
        await apiReceitas.post('/receitas', receita);
    }

    const deletarPorId = async (id: string) => {
        await apiReceitas.delete(`/receitas/${id}`);
    }

    return {
        listar,
        obterPorId,
        criar,
        deletarPorId
    }

}