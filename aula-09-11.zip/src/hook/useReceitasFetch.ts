import { Receita } from "@/types/receita";

const URL_API = "http://10.10.85.43:3000/receitas"

export function useReceitasFetch() {

    const listar = async (): Promise<Receita[]> => {
        const resposta = await fetch(URL_API);
        return await resposta.json();
    }

    const obterPorId = async (id: string): Promise<Receita> => {
        const resposta = await fetch(`${URL}/${id}`)
        return await resposta.json()
    }

    const criar = async (receita: Omit<Receita, "id">) => {
        const resposta = await fetch(URL_API, {
            method: 'POST',
            body: JSON.stringify(receita),
            headers: {
                "Content-type": "application/json",
            }
        })

        if (!resposta.ok) {
            throw new Error('Erro ao cadastrar receita!');
        }
    }

    const deletarPorId = async (id: string) => {
        const resposta = await fetch(URL_API + `/${id}`, {
            method: 'DELETE'            
        })

        if (!resposta.ok) {
            throw new Error("Erro ao excluir!");
        }
    }

    return {
        listar,
        obterPorId,
        criar,
        deletarPorId
    }
}